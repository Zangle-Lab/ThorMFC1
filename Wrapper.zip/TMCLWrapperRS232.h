
#ifdef TMCLWRAPPERRS232_EXPORTS
#define TMCLWRAPPERRS232_API __declspec(dllexport) 
#else
#define TMCLWRAPPERRS232_API __declspec(dllimport)
#endif

#define CALLMETHOD _stdcall

#define TMCL_ROR 1
#define TMCL_ROL 2
#define TMCL_MST 3
#define TMCL_MVP 4
#define TMCL_SAP 5
#define TMCL_GAP 6
#define TMCL_STAP 7
#define TMCL_RSAP 8
#define TMCL_SGP 9
#define TMCL_GGP 10
#define TMCL_STGP 11
#define TMCL_RSGP 12
#define TMCL_RFS 13
#define TMCL_SIO 14
#define TMCL_GIO 15
#define TMCL_SCO 30
#define TMCL_GCO 31
#define TMCL_CCO 32


#define TMCL_RESULT_OK 0
#define TMCL_RESULT_NOT_READY 1
#define TMCL_RESULT_CHECKSUM_ERROR 2


#define MVP_ABS 0
#define MVP_REL 1
#define MVP_COORD 2


#define RFS_START 0
#define RFS_STOP 1
#define RFS_STATUS 2


extern "C"
{
  TMCLWRAPPERRS232_API HANDLE CALLMETHOD OpenRS232(const char *ComName, DWORD BaudRate);
  TMCLWRAPPERRS232_API void CALLMETHOD CloseRS232(HANDLE Handle);
	TMCLWRAPPERRS232_API void CALLMETHOD SendCmd(HANDLE Handle, UCHAR Address, UCHAR Command, UCHAR Type, UCHAR Motor, INT Value);
  TMCLWRAPPERRS232_API UCHAR CALLMETHOD GetResult(HANDLE Handle, UCHAR *Address, UCHAR *Status, int *Value);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLRotateRight(HANDLE Handle, UCHAR Address, UCHAR Motor, INT Value); 
  TMCLWRAPPERRS232_API void CALLMETHOD TMCLRotateLeft(HANDLE Handle, UCHAR Address, UCHAR Motor, INT Value);
  TMCLWRAPPERRS232_API void CALLMETHOD TMCLMotorStop(HANDLE Handle, UCHAR Address, UCHAR Motor);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLMoveToPosition(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor, INT Value);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLSetAxisParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor, INT Value);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLGetAxisParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLStoreAxisParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLRestoreAxisParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLSetGlobalParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Bank, INT Value);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLGetGlobalParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Bank);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLStoreGlobalParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Bank);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLRestoreGlobalParameter(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Bank);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLReferenceSearch(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLSetOutput(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Bank, INT Value);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLGetInput(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Bank);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLSetCoordinate(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor, INT Value);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLGetCoordinate(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor);
	TMCLWRAPPERRS232_API void CALLMETHOD TMCLCaptureCoordinate(HANDLE Handle, UCHAR Address, UCHAR Type, UCHAR Motor);
}

